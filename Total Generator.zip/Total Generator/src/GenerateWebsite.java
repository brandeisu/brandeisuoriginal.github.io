import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;


public class GenerateWebsite {
	
	public static String masterTemplate;
	
	public static void main(String[] args){
		int processed = compileContentInFolder(".");	
		System.out.println("\n" + processed + " files created in total.\n");
		int ran = executeJavaFilesInFolder(".");
		System.out.println("\n" + ran + " executables ran.\n");
	}
	
	public static String getMasterTemplate(){
		if (masterTemplate == null){
			File f = new File("master-template.txt");
			String result = getContentsOfFile(f);
			masterTemplate = result;
		}
		return masterTemplate;
	}
	
	public static int compileContentInFolder(String folderName){
		return compileContentInFolder(folderName, 0);
	}
	
	public static int compileContentInFolder(String folderName, int dots){
		int total = 0;
		File folder = new File(folderName);
		File[] listOfFiles = folder.listFiles();
		for (File f : listOfFiles){
			String name = f.getName();
			if (!name.startsWith(".")){
				if (f.isDirectory()){
					total += compileContentInFolder(f.getAbsolutePath(), dots+1);
				} else {
					total += compileContentFile(f, dots);
				}
			}
		}
		return total;
	}
	
	public static int compileContentFile(File f, int dots){
		if (f.getName().equals("content.txt")){
			String path = f.getAbsolutePath();
			String abrevPath = path.substring(0, path.lastIndexOf("/"));
			processTemplatingFiles(f, new File(abrevPath + "/index.html"), dots);
			return 1;
		} else if (f.getName().equals("content-template.txt")){
			String path = f.getAbsolutePath();
			String abrevPath = path.substring(0, path.lastIndexOf("/"));
			processTemplatingFiles(f, new File(abrevPath + "/template.txt"), dots-1);
			return 1;
		}
		return 0;
	}
	
	public static int executeJavaFilesInFolder(String folderName){
		int total = 0;
		File folder = new File(folderName);
		File[] listOfFiles = folder.listFiles();
		for (File f : listOfFiles){
			String name = f.getName();
			if (!name.startsWith(".")){
				if (f.isDirectory()){
					total += executeJavaFilesInFolder(f.getAbsolutePath());
				} else {
					total += executeJavaFile(f);
				}
			}
		}
		return total;
	}
	
	public static int executeJavaFile(File f){
		if (f.getName().endsWith(".class")){
			Runtime rt = Runtime.getRuntime();	
			try {
				rt.exec("java " + f.getAbsolutePath().substring(0, f.getAbsolutePath().indexOf(".class")));
			} catch (IOException e) {
				System.err.println("There was an error running the java class: " + f.getName());
			}
			System.out.println("Ran Executable: " + f.getAbsolutePath());
			return 1;
		}
		return 0;
	}
	
	public static void processTemplatingFiles(File inputContentFile, File outputCreatedFile, int dots){
		
		String prefix = "";
		for (int i = 0; i < dots; i++){
			prefix += "../";
		}
		
		String content = getContentsOfFile(inputContentFile);
		String templateToEdit = getMasterTemplate();
		templateToEdit = templateToEdit.replace("[DOTS]", prefix);
		templateToEdit = templateToEdit.replace("[CONTENT]", content);
		
		System.out.println("Created File: " + outputCreatedFile.getAbsolutePath());
		
		writeStringToFile(templateToEdit, outputCreatedFile);
	}
	
	public static void writeStringToFile(String s, File f){
		try {
			PrintWriter pw = new PrintWriter(f);
			pw.println(s);
			pw.close();
		} catch (FileNotFoundException e) {
			System.err.println("FILE NOT FOUND FOR OUTPUT");
			return;
		}
	}
	
	public static String getContentsOfFile(File f){
		try {
			Scanner scan = new Scanner(f);
			String result = "";
			while (scan.hasNextLine()){
				result += scan.nextLine() + "\n";
			}
			scan.close();
			return result;
		} catch (FileNotFoundException e) {
			System.err.println("INPUT FILE NOT FOUND");
			return null;
		}
	}
	
}
