(function($){
  $(function(){

    $('.button-collapse').sideNav();
    
    $(".dropdown-button").dropdown();

  }); // end of document ready
})(jQuery); // end of jQuery name space